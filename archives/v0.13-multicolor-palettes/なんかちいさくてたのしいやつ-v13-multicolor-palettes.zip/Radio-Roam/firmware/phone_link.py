"""Read-only Android browser companion over the device's temporary Wi-Fi AP."""
import socket,time,os,json
import world


class PhoneLink:
    def __init__(self,app):
        import network
        self.app=app
        token=os.urandom(4)
        self.ssid='Roam-%02x%02x'%(token[0],token[1])
        self.password='%08d'%(int.from_bytes(token,'little')%100000000)
        self.ap=network.WLAN(network.AP_IF)
        self.ap.active(True)
        self.server=None
        try:
            self.ap.config(essid=self.ssid,password=self.password,authmode=network.AUTH_WPA2_PSK)
            self.server=socket.socket()
            self.server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            self.server.bind(('0.0.0.0',80)); self.server.listen(2); self.server.setblocking(False)
        except Exception:
            if self.server: self.server.close()
            self.ap.active(False)
            raise
        self.clients=[]

    def response(self,path):
        if path=='/':
            with open('assets/phone.html','rb') as f: return 'text/html; charset=utf-8',f.read()
        if path=='/api/state':
            return 'application/json; charset=utf-8',json.dumps(world.public_state(self.app.state)).encode()
        if path.startswith('/api/sprite?id='):
            query=path.split('?',1)[1]
            values={pair.split('=',1)[0]:pair.split('=',1)[1] for pair in query.split('&') if '=' in pair}
            uid=values.get('id','')
            try: stage=int(values['stage']) if 'stage' in values else None
            except ValueError: stage=None
            pets=world.roster(self.app.state)+self.app.state['dex']+[e['child'] for e in self.app.state['eggs']]
            p=next((p for p in pets if p['uid']==uid and p['evolution']==stage),None) if stage is not None else None
            if p is None: p=next((p for p in pets if p['uid']==uid),None)
            if p: return 'application/json',json.dumps(self.app.screen.export_sprite(p)).encode()
        return None,b'Not found'

    def poll(self):
        try:
            c,_=self.server.accept()
            c.setblocking(False)
            if len(self.clients)>=2: c.close()
            else: self.clients.append({'s':c,'request':b'','output':None,'at':time.ticks_ms(),'sent':0})
        except OSError: pass
        for client in self.clients[:]:
            try:
                if time.ticks_diff(time.ticks_ms(),client['at'])>20000: raise ValueError('timeout')
                if client['output'] is None:
                    try: chunk=client['s'].recv(512)
                    except OSError: continue
                    if not chunk: raise ValueError('closed')
                    client['request']+=chunk
                    if len(client['request'])>2048: raise ValueError('request too big')
                    if b'\r\n\r\n' not in client['request']: continue
                    line=client['request'].split(b'\r\n',1)[0].decode().split()
                    if len(line)!=3 or line[0]!='GET': raise ValueError('GET only')
                    content,body=self.response(line[1])
                    status='200 OK' if content else '404 Not Found'
                    headers=('HTTP/1.1 %s\r\nContent-Type: %s\r\nContent-Length: %d\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n'%(status,content or 'text/plain',len(body))).encode()
                    client['output']=headers+body
                try:
                    n=client['s'].send(memoryview(client['output'])[client['sent']:client['sent']+2048])
                except OSError: continue
                client['sent']+=n; client['at']=time.ticks_ms()
                if client['sent']>=len(client['output']): raise ValueError('done')
            except (ValueError,OSError,UnicodeError):
                client['s'].close(); self.clients.remove(client)

    def close(self):
        for c in self.clients: c['s'].close()
        self.clients=[]; self.server.close(); self.ap.active(False)
