"""Exact modular semantic-colour renderer for 64x64 monsters."""
import framebuf
from world import PARTS,visual_part_value
from pet_screen import rgb
from part_catalog import SEMANTIC_PALETTES


class Art:
    def __init__(self):
        self.part_file=open('assets/parts.idx','rb')
        with open('assets/parts.cat','rb') as source: self.catalog=bytearray(source.read())
        self.asset_parts=('body','head','arms','legs','horns','tail','eyes','wings')
        self.palettes=[]
        for colors in SEMANTIC_PALETTES:
            palette=framebuf.FrameBuffer(bytearray(512),256,1,framebuf.RGB565)
            for index,(red,green,blue) in enumerate(colors):
                palette.pixel(index,0,rgb(red,green,blue))
            self.palettes.append(palette)
        self.cache={}; self.scaled_cache={}; self.ink=1

    def palette_for(self,p):
        return self.palettes[p.get('palette',0)%len(self.palettes)]

    def rgb_palette_for(self,p):
        return [list(color) for color in SEMANTIC_PALETTES[p.get('palette',0)%len(SEMANTIC_PALETTES)]]

    def _part(self,p,name,stage):
        slot=PARTS.index(name)
        slot_value=visual_part_value(p,slot)
        # Every type has three interchangeable shapes per visible slot.  The
        # catalog's type index selects the dedicated kit before this value is
        # applied, so parts from another species can never enter the lookup.
        value=slot_value%3
        index=(((p['type']*16+value)*3+stage)*8+self.asset_parts.index(name))*8
        offset=(self.catalog[index]<<24)|(self.catalog[index+1]<<16)|(self.catalog[index+2]<<8)|self.catalog[index+3]
        w,h,x,y=self.catalog[index+4],self.catalog[index+5],self.catalog[index+6],self.catalog[index+7]
        self.part_file.seek(offset); data=bytearray(self.part_file.read(w*h))
        return data,(offset,w,h,x,y),framebuf.FrameBuffer(data,w,h,framebuf.GS8)

    def compose(self,p,frame=0):
        stage=p.get('evolution',0)
        present=tuple(p.get('present',[True]*8))
        key=(p['type'],tuple(p['parts']),present,stage,tuple(p.get('evolution_paths',())),frame)
        if key in self.cache: return self.cache[key]
        buf=bytearray(4096); fb=framebuf.FrameBuffer(buf,64,64,framebuf.GS8)
        # The legacy eyes slot carries a type-specific back/crown accessory for
        # beast, humanoid and plant kits.  Draw it behind the body; visible eyes
        # are already integrated into every type's head artwork.
        order=('wings','eyes','tail','legs','body','arms','head','horns')
        for name in order:
            index=PARTS.index(name)
            if not present[index]: continue
            part_data,entry,source=self._part(p,name,stage)
            _,w,h,x,y=entry
            if frame==1 and name not in ('legs','tail'): y-=1
            elif frame==3 and name in ('tail','wings'): y-=2
            elif frame==4 and name in ('head','arms','horns','eyes'): x+=2; y-=1
            elif frame==5 and name not in ('legs','tail'): x-=1
            elif frame==6: y-=2
            elif frame==7 and name in ('head','eyes','horns'): y+=2
            fb.blit(source,x,y,0)
        if len(self.cache)>=24: self.cache.clear()
        self.cache[key]=(buf,fb); return buf,fb

    def draw(self,target,p,frame,x,y,size=64,mirror=False):
        buf,source=self.compose(p,frame); palette=self.palette_for(p)
        if size==64 and not mirror:
            target.blit(source,x,y,0,palette); return
        key=(p['type'],tuple(p['parts']),tuple(p.get('present',[True]*8)),
             p.get('evolution',0),tuple(p.get('evolution_paths',())),frame,size,mirror)
        if key not in self.scaled_cache:
            data=bytearray(size*size); scaled=framebuf.FrameBuffer(data,size,size,framebuf.GS8)
            for yy in range(size):
                for xx in range(size):
                    source_x=(size-1-xx)*64//size if mirror else xx*64//size
                    scaled.pixel(xx,yy,source.pixel(source_x,yy*64//size))
            if len(self.scaled_cache)>=32: self.scaled_cache.clear()
            self.scaled_cache[key]=(data,scaled)
        target.blit(self.scaled_cache[key][1],x,y,0,palette)

    def export(self,p):
        from world import hexed
        data,_=self.compose(p)
        return {'width':64,'height':64,'pixels':hexed(data),'palette':self.rgb_palette_for(p)}
